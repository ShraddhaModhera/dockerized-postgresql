-- Create a new database named irdb
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT FROM pg_database WHERE datname = 'irdb') THEN
        CREATE DATABASE irdb;
    END IF;
END $$;

-- Create a new user named rtb_qa with password rtb_qa if it does not exist
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'rtb_qa') THEN
        CREATE USER rtb_qa WITH PASSWORD 'rtb_qa';
    END IF;
END $$;

--CREATE ROLE rtb_qa WITH LOGIN PASSWORD 'rtb_qa';

-- Create a new schema named rtb_dev
--CREATE SCHEMA IF NOT EXISTS rtb_dev;

-- Change ownership of the rtb_dev schema to rtb_dev user
--ALTER SCHEMA rtb_dev OWNER TO rtb_dev;

-- Change the default schema search path for the rtb_dev user to rtb_dev schema
--ALTER USER rtb_dev SET search_path to rtb_dev;

-- Grant rtb_dev user permission to connect to the irdb database
GRANT CONNECT ON DATABASE irdb to rtb_qa;